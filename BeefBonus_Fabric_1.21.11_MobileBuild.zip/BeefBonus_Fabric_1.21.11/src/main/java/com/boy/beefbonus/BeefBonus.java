package com.boy.beefbonus;

import net.fabricmc.api.ModInitializer;

public final class BeefBonus implements ModInitializer {
    @Override
    public void onInitialize() {
        // Reward logic runs from the LivingEntity completion mixin.
    }
}
